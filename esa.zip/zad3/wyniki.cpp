#include "testheader.h"
#include <stdio.h>
#include <foobaz.h>   
brief Java style Doc String - Foo function */
int foo();

int bar(); 
int g_global_var = 1;

int baz();

volatile int g_global;

int main(int argc, const char* argv)
{
    printf(" bar();

        foo();


    foo();

    return 1;
}